package com.example.demo.controller;

import java.util.List;

import org.springframework.stereotype.Controller;

import com.example.demo.entity.TodoItem;
import com.example.demo.repo.TodoItemRepository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class TodoController {

    private final TodoItemRepository todoItemRepository;

    public TodoController(TodoItemRepository todoItemRepository) {
        this.todoItemRepository = todoItemRepository;
    }
  

    @GetMapping("/tasks")
    public String viewTasks(Model model) {
        List<TodoItem> tasks = todoItemRepository.findAll();
        model.addAttribute("tasks", tasks);
        return "task-list"; // Return the name of the HTML template to render the tasks.
    }
//
//    @GetMapping("/")
//    public String index(Model model) {
//        model.addAttribute("todoItems", todoItemRepository.findAll());
//        return "index";
//    }

    @PostMapping("/add")
    public String addTodoItem(@ModelAttribute TodoItem todoItem) {
        todoItemRepository.save(todoItem);
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String deleteTodoItem(@PathVariable Long id) {
        todoItemRepository.deleteById(id);
        return "redirect:/";
    }
}
